<?php 
include('./references/config.php');
include('./references/date.php');
include('./references/icons.php');



// Check if user is logged in
if(!isset($_SESSION['firstName'])) {
	header("location: login.php");
	$_SESSION['error'] = "<div class='error'>You must be logged in to acccess this page.</div>";

}

// Check if logged in user is an admin
if(!isset($_SESSION['admin']) || $_SESSION['admin'] != 1) {
	header("location: login.php");
	$_SESSION['error'] = "<div class='error'>You must be an admin to acccess this page.</div>";
}

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Centerville Nutrition</title>
		<!-- <link rel="stylesheet" href="styles/styles.css"> -->

		<link rel="stylesheet" href="styles/account.css">
		<link rel="stylesheet" href="styles/admin.css">
		<link rel="stylesheet" href="styles/cart.css">
		<link rel="stylesheet" href="styles/checkout.css">
		<link rel="stylesheet" href="styles/general.css">
		<link rel="stylesheet" href="styles/home.css">
		<link rel="stylesheet" href="styles/items.css">
		<link rel="stylesheet" href="styles/mMenu.css">
		<link rel="stylesheet" href="styles/products.css">
		<link rel="stylesheet" href="styles/register.css">
		<link rel="stylesheet" href="styles/rewards.css">
		<link rel="preconnect" href="https://fonts.googleapis.com" />
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
		<link rel="icon" href="./menuImages/Shake.png" type="image/icon type">
		<link
			href="https://fonts.googleapis.com/css2?family=IM+Fell+DW+Pica:ital@0;1&family=Playball&display=swap"
			rel="stylesheet"
		/>

		<link rel="preconnect" href="https://fonts.googleapis.com" />
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
		<link
			href="https://fonts.googleapis.com/css2?family=Geologica:wght@100..900&family=Playball&display=swap"
			rel="stylesheet"
		/>
	</head>
	<body>
		
		<div class="container">
			
			<nav class="home-nav admin-top">
				<a class="logo admin-logo" href="index.php">
					<h1>Centerville Nutrition</h1>
					<span>
						<div class="logoUnder1"></div>
						<div class="logoUnder2"></div>
					</span>
				</a>

				<div class="main-nav admin-nav">
                <div class="main-nav">			
			<?php
			if (isset($_SESSION['admin'])) {
				// If user is an admin, display admin button on page
				if($_SESSION['admin'] == 1) {
					echo ("<a href='editMenu.php'>Admin</a>");
				} 
			}
			?>
			
			<a href="menu.php">Menu</a>
			<a href="rewards.php">Rewards</a>

            <?php 
			// Check if the user is logged in and display their name if so
            if (!isset($_SESSION['firstName'])) {
                echo "<a href='login.php'>Sign In</a>";
            } else {
                echo "<a href='user.php'>" . ($_SESSION['firstName']) . "</a>";
				$firstName = $_SESSION['firstName'];
          
				// Retrieve user's cart and display the number of items

				if($dataClass->searchData("cart", "CartID" ,$dataClass->searchData("user", "email", $_SESSION['email'])["CartID"])["ItemList"] != "")
				{
				$cartCount = count($dataClass->cartToArray(($dataClass->searchData("cart", "CartID" ,$dataClass->searchData("user", "email", $_SESSION['email'])["CartID"])["ItemList"])));
				}else
				{
					$cartCount = 0;
					$_SESSION['itemArray'] = array();
				}

			?>
			<a href="cart.php"><?php if($cartCount >= 0) {
				echo("<div style='font-size: 30px; position: absolute; color: black; z-index: 0;'>" . $cartCount . "</div>");
			}  }
			?><svg class="icon-bag" version="1.1" viewBox="0.0 0.0 149.35958005249344 115.65879265091864" fill="none" stroke="none" stroke-linecap="square" stroke-miterlimit="10" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><clipPath id="p.0"><path d="m0 0l149.35957 0l0 115.65879l-149.35957 0l0 -115.65879z" clip-rule="nonzero"/></clipPath><g clip-path="url(#p.0)"><path fill="#000000" fill-opacity="0.0" d="m0 0l149.35957 0l0 115.65879l-149.35957 0z" fill-rule="evenodd"/><path fill="#fff9fb" d="m34.52231 46.143044l0 0c0 -25.409575 17.867249 -46.04065 39.97361 -46.156994c22.106361 -0.1163453 40.13723 20.3258 40.33967 45.73431l-12.22892 0.12872314l0 0c-0.13323212 -18.679798 -12.671074 -33.71457 -28.047867 -33.63364c-15.376793 0.08092785 -27.80693 15.247105 -27.80693 33.9276z" fill-rule="evenodd"/><path fill="#fff9fb" d="m2.0341208 43.640434l0 0c0 -7.3754005 5.978943 -13.354345 13.354343 -13.354345l118.58265 0c3.5417938 0 6.9385223 1.406971 9.442947 3.911398c2.504425 2.504425 3.9113922 5.9011536 3.9113922 9.442947l0 58.67714c0 7.3753967 -5.978943 13.35434 -13.35434 13.35434l-118.58265 0c-7.3754005 0 -13.354343 -5.978943 -13.354343 -13.35434z" fill-rule="evenodd"/></g></svg></a>
		</div>
			</nav>
		</head>
		